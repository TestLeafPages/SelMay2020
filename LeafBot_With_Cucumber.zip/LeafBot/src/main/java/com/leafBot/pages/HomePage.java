package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.xml.sax.Locator;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class HomePage extends ProjectSpecificMethods{

	

	
	@Then("(.*) should be displayed in HomePage")
	public HomePage verifyLoggedName(String data) {
		verifyPartialText(locateElement("xpath", "//h2[text()[contains(.,'Demo')]]"), data);
		return this;
	}

	

	
	public LoginPage clickLogout() {
		click(locateElement("class", "decorativeSubmit"));
		return new LoginPage();

	}
	
	

}










