package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import utils.ReadExcel;

public class ProjectSpecificMethods {

	public ChromeDriver driver;

	public String fileName;
	
	public static Properties prop;

	@Parameters("language")
	@BeforeSuite
	public void loadProperties(String lang) throws FileNotFoundException, IOException {
		prop = new Properties();
		prop.load(new FileInputStream("./src/main/resources/"+lang+".properties"));

	}

	@Parameters("url")
	@BeforeMethod
	public void startApp(String url) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);

	}

	@AfterMethod
	public void closeBrowser() {
		driver.close();

	}

	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException {

		return ReadExcel.readData(fileName);

	}

}
