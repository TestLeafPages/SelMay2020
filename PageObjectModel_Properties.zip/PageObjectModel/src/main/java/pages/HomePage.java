package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	
	
	public HomePage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	
	
	//click logout button
	
	public LoginPage clickLogoutButton() {
		driver.findElementByXPath(prop.getProperty("HomePage.logout.xpath")).click();
		
		return new LoginPage(driver);
	}

	// click crmsfa link
	
	public MyHomePage clickCrmsfaLink() {
		driver.findElementByLinkText(prop.getProperty("HomePage.crmsfa.linktext")).click();
		
		return new MyHomePage();

	}
	
	
	public HomePage verifyHomePage() {
		Assert.assertTrue(driver.findElementByLinkText("CRM/SFA").isDisplayed());
		
		return this;
	}
	
}
