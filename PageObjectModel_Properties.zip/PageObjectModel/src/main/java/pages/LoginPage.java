package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
	}

	// enter username

	public LoginPage enterUsername(String data) throws InterruptedException {

		driver.findElementById(prop.getProperty("LoginPage.username.id")).sendKeys(data);
		Thread.sleep(4000);
		return this;

	}

	// enter password

	public LoginPage enterPassword(String data) {
		driver.findElementById(prop.getProperty("LoginPage.password.id")).sendKeys(data);

		return this;
	}

	// click login

	public HomePage clickLoginButton() {
		driver.findElementByClassName(prop.getProperty("LoginPage.login.class")).click();

		// HomePage hp = new HomePage();

		return new HomePage(driver);

	}

}
