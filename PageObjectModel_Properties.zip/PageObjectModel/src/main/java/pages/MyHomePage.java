package pages;

import base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods {

}
