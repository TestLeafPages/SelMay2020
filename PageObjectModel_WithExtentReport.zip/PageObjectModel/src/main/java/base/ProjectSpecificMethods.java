package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


import utils.ReadExcel;

public class ProjectSpecificMethods {

	public ChromeDriver driver;

	public String fileName;

	public static Properties prop;
	
	
	public static ExtentHtmlReporter reporter;
	public static ExtentReports extent;
	
	public ExtentTest test,eachNode;
	
	public String testName,testDesc,testAuthor,testCategory;
	

	@Parameters("language")
	@BeforeSuite
	public void loadProperties(String lang) throws FileNotFoundException, IOException {
		prop = new Properties();
		prop.load(new FileInputStream("./src/main/resources/" + lang + ".properties"));

		
		reporter = new ExtentHtmlReporter("./extentReport/result.html");

		reporter.setAppendExisting(true);

		// To design the report
		extent = new ExtentReports();

		// to attach the design with physical report
		extent.attachReporter(reporter);

	}
	
	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDesc);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);

	}
	
	
	public long takeSnap() throws IOException {
		
		long number =(long)Math.floor((Math.random()*90000000L)+10000000L);
		
		File src = driver.getScreenshotAs(OutputType.FILE);
		File dest = new File("./snaps/img"+number+".png");
		FileUtils.copyFile(src, dest);
		
		return number;

	}
	
	
	
	public void reportStep(String msg,String status) throws IOException {
		
		if(status.equals("pass")){
			eachNode.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
		else {
			eachNode.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}
		

	}
	
	
	
	
	
	

	@Parameters("url")
	@BeforeMethod
	public void startApp(String url) {
		
		 eachNode = test.createNode(testName);
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);

	}

	@AfterMethod
	public void closeBrowser() {
		driver.close();

	}

	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException {

		return ReadExcel.readData(fileName);

	}
	
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}

}
