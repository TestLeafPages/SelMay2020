package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	
	
	public HomePage(ChromeDriver driver,ExtentTest test,ExtentTest eachNode) {
		this.driver = driver;
		this.test = test;
		this.eachNode = eachNode;
	}
	
	
	
	//click logout button
	
	public LoginPage clickLogoutButton() throws IOException {
		try {
			driver.findElementByXPath(prop.getProperty("HomePage.logout.xpath")).click();
			reportStep("logout button clicked successfully","pass");
		} catch (Exception e) {
			reportStep("logout button not clicked successfully","fail");
		}
		
		return new LoginPage(driver,test,eachNode);
	}

	// click crmsfa link
	
	/*
	 * public MyHomePage clickCrmsfaLink() {
	 * driver.findElementByLinkText(prop.getProperty("HomePage.crmsfa.linktext")).
	 * click();
	 * 
	 * return new MyHomePage();
	 * 
	 * }
	 */
	
	
	public HomePage verifyHomePage() throws IOException {
		try {
			Assert.assertTrue(driver.findElementByLinkText("CRM/SFA").isDisplayed());
			reportStep("crmsfa link is displayed successfully","pass");
		} catch (Exception e) {
			reportStep("crmsfa link is not displayed successfully","fail");
		}
		
		return this;
	}
	
}
