package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage(ChromeDriver driver,ExtentTest test,ExtentTest eachNode) {
		this.driver = driver;
		this.test = test;
		this.eachNode = eachNode;
	}

	// enter username

	public LoginPage enterUsername(String data) throws InterruptedException, IOException {

		try {
			driver.findElementById(prop.getProperty("LoginPage.username.id")).sendKeys(data);
			reportStep("username entered successfully","pass");
		} catch (Exception e) {
			reportStep("username not entered successfully","fail");
		}
		
		return this;

	}

	// enter password

	public LoginPage enterPassword(String data) throws IOException {
		try {
			driver.findElementById(prop.getProperty("LoginPage.password.id")).sendKeys(data);
			reportStep("password entered successfully","pass");
		} catch (Exception e) {
			reportStep("password not entered successfully","fail");
			
		}

		return this;
	}

	// click login

	public HomePage clickLoginButton() throws IOException {
		try {
			driver.findElementByClassName(prop.getProperty("LoginPage.login.class")).click();
			reportStep("login button clicked successfully","pass");
		} catch (Exception e) {
			reportStep("login button not clicked successfully","fail");
		}

		// HomePage hp = new HomePage();

		return new HomePage(driver,test,eachNode);

	}

}
