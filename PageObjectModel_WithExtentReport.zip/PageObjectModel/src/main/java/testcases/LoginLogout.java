package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setData() {
		fileName = "TC001";
		testName="LoginLogout";
		testDesc="Test login for positive values";
		testAuthor = "Hari";
		testCategory = "functional";
		

	}
	
	
	@Test(dataProvider="fetchData")
	public void runLoginLogout(String username,String password) throws InterruptedException, IOException {
		
		 // LoginPage lp = new LoginPage();
		
		new LoginPage(driver,test,eachNode)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickLogoutButton();
		

	}
	

}
