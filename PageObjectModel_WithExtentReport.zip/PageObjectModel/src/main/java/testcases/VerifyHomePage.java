package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class VerifyHomePage extends ProjectSpecificMethods {
	

	@BeforeTest
	public void setData() {
		fileName = "TC002";
		testName="Verify Homepage";
		testDesc="Test the display of Homepage";
		testAuthor = "Naveen";
		testCategory = "Regression";
		

	}
	
	
	@Test(dataProvider="fetchData")
	public void runVerification(String username,String password) throws InterruptedException, IOException {
		
		new LoginPage(driver,test,eachNode)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.verifyHomePage();
		

	}

}
