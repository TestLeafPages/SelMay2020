package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features= {"src/test/java/features"},
				 glue="steps",
				 monochrome=true,
			//	 tags= {"@regression,@smoke"} //or
			//	 tags = {"@sanity","@regression"} // and
			//	 tags = {"~@regression,@sanity"} //not
						 tags = {"@sanity"},
						 plugin = {"pretty","html:reports"}
				 //snippets=SnippetType.CAMELCASE
				 )
public class RunLogin extends AbstractTestNGCucumberTests {
	


}
